package primitives;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class VectorTest {

    @Test
    void equals1() {
        Vector v1 = new Vector(new Point3D(1,2.00002,3));
        Vector v2 = new Vector(new Point3D(1,2,4));
        assertTrue(v1.equals(v1));
        assertFalse(v1.equals(v2));
    }

    @Test
    void add() {
        Vector v = new Vector(new Point3D(3,6.00002,9));
        Vector v1 = new Vector(new Point3D(1,2.00002,3));
        Vector v2 = new Vector(new Point3D(2,4,6));
        Vector v3=v1.add(v2);

        assertEquals(v.getHead().getX()._coord,v3.getHead().getX()._coord,1e-10);
        assertEquals(v.getHead().getY()._coord,v3.getHead().getY()._coord,1e-10);
        assertEquals(v.getHead().getZ()._coord,v3.getHead().getZ()._coord,1e-10);
    }

    @Test
    void subtract() {
        Vector v = new Vector(new Point3D(1,1.99998,3));
        Vector v1 = new Vector(new Point3D(1,2.00002,3));
        Vector v2 = new Vector(new Point3D(2,4,6));
        Vector v3=v2.subtract(v1);

        assertEquals(v.getHead().getX()._coord,v3.getHead().getX()._coord,1e-10);
        assertEquals(v.getHead().getY()._coord,v3.getHead().getY()._coord,1e-10);
        assertEquals(v.getHead().getZ()._coord,v3.getHead().getZ()._coord,1e-10);
    }

    @Test
    void scale() {
        Vector v = new Vector(new Point3D(2,4.00004,6));
        Vector v1 = new Vector(new Point3D(1,2.00002,3));
        Vector v2=v1.scale(2);

        assertEquals(v.getHead().getX()._coord,v2.getHead().getX()._coord,1e-10);
        assertEquals(v.getHead().getY()._coord,v2.getHead().getY()._coord,1e-10);
        assertEquals(v.getHead().getZ()._coord,v2.getHead().getZ()._coord,1e-10);
    }

    @Test
    void dotProduct() {
        double d1 = 28.00008;
        Vector v1 = new Vector(new Point3D(1,2.00002,3));
        Vector v2 = new Vector(new Point3D(2,4,6));
        double d2 = v2.dotProduct(v1);

        assertEquals(d2,d1,1e-10);
    }

    @Test
    void crossProduct() {
        Vector v = new Vector(new Point3D(-3,6,-3));
        Vector v1 = new Vector(new Point3D(1,2,3));
        Vector v2 = new Vector(new Point3D(4,5,6));
        Vector v3=v1.crossProduct(v2);

        assertEquals(v.getHead().getX()._coord,v3.getHead().getX()._coord,1e-10);
        assertEquals(v.getHead().getY()._coord,v3.getHead().getY()._coord,1e-10);
        assertEquals(v.getHead().getZ()._coord,v3.getHead().getZ()._coord,1e-10);
    }

    @Test
    void length() {
        Vector v = new Vector(new Point3D(3,4,0));
        double l = 5;

        assertEquals(l, v.length(), 1e-10);
    }

    @Test
    void normalize() {//ERROR EXPECTED
        Vector v = new Vector(new Point3D(.5, -5, 10));
        v = v.normalize();
        assertEquals(1, v.length(), 1e-10);
        v = new Vector(new Point3D(1,1,1));
        try {
            v = new Vector(new Point3D(1,1,1));
            v = v.subtract(v);
            fail("Didn't throw divide by zero exception!");
        } catch (ArithmeticException e) {
            assertTrue(true);
        }
    }
}