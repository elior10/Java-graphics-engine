package primitives;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class Point3DTest {

    @Test
    void distanceTest1() {
        Point3D p1 = new Point3D(1.0,2.0,3.5);
        Point3D p2 = new Point3D(1.0,2.000045,3.5);

        assertEquals(0.0,p1.distance(p2),0.00001);
    }
    @Test
    void distanceTest2() {
        Point3D p1 = new Point3D(1.0,1.0,3.5);
        Point3D p2 = new Point3D(1.0,2.000000025,4.5);

        assertEquals(2.0,p1.distance(p2),0.0000001);
    }
}