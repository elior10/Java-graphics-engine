package renderer;

import org.junit.jupiter.api.Test;

import java.awt.*;

import static org.junit.jupiter.api.Assertions.*;

class ImageWriterTest {

    @Test
    void writePixel() {
        ImageWriter imgWriter = new ImageWriter("myImg",500,500,10,10);
        for (int i=0; i<10; i++)
            for (int j=0; j<10; j++) {
                imgWriter.writePixel(i, j, new Color(255,0,255));
            }
        imgWriter.writeToimage();
    }
}