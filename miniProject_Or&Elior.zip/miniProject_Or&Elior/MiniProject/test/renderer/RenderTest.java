// קרדיט ליוחנן חייק ולעידו הראל

package renderer;

import Elements.Camera;
import geometries.*;
import org.junit.jupiter.api.Test;
import primitives.*;
import renderer.ImageWriter;
import renderer.Render;
import scene.Scene;

import java.util.ArrayList;
import java.util.List;

public class RenderTest {
	@Test
	public void basicRendering() throws Exception {
		Scene scene = new Scene("Test ");
		scene.setCamera(new Camera(new Point3D(0, 0, 0), new Vector(new Point3D(0, -1, 0)), new Vector(new Point3D(0, 0, 1))));
		scene.setScreenDistance(100);
		scene.setBackground(new java.awt.Color(0, 0, 0));
		List<Geometry> geometries = new ArrayList<>();
		scene.set_geometries(geometries);
		geometries.add(new Sphere(new Color(100, 100,100 ), 50, new Point3D(0, 0, 150)));

		geometries.add(new Triangle(new Color(100, 100,100 ), new Point3D( 100, 0, 149),
				 							new Point3D(  0, 100, 149),
				 							new Point3D( 100, 100, 149)));

		geometries.add(new Triangle(new Color(100, 100,100 ), new Point3D( 100, 0, 149),
				 			 				new Point3D(  0, -100, 149),
				 			 				new Point3D( 100,-100, 149)));

		geometries.add(new Triangle(new Color(100, 100,100 ), new Point3D(-100, 0, 149),
				 							new Point3D(  0, 100, 149),
				 							new Point3D(-100, 100, 149)));

		geometries.add(new Triangle(new Color(100, 100,100 ), new Point3D(-100, 0, 149),
				 			 				new Point3D(  0,  -100, 149),
				 			 				new Point3D(-100, -100, 149)));

		ImageWriter imageWriter = new ImageWriter("test0", 500, 500, 500, 500);
		Render render = new Render(imageWriter, scene);

		render.renderImage();
		render.printGrid(50);
		render.writeToImage();
	}
}