package renderer;

import Elements.Camera;
import Elements.PointLight;
import Elements.SpotLight;
import geometries.*;
import org.junit.jupiter.api.Test;
import primitives.Material;
import primitives.Point3D;
import primitives.Vector;
import primitives.Color;
import scene.Scene;
import renderer.ImageWriter;
import renderer.Render;

import java.awt.*;

public class RenderTest2 {

    @Test
    public void basicRendering() throws Exception {

        Scene scene = new Scene("Test2");

        scene.addGeometry(new Sphere(50, new Point3D(0.0, 0.0, -150)));

        Triangle triangle = new Triangle(new Point3D( 100, 0, -149),
                new Point3D(  0, 100, -149),
                new Point3D( 100, 100, -149));

        Triangle triangle2 = new Triangle(new Point3D( 100, 0, -149),
                new Point3D(  0, -100, -149),
                new Point3D( 100,-100, -149));

        Triangle triangle3 = new Triangle(new Point3D(-100, 0, -149),
                new Point3D(  0, 100, -149),
                new Point3D(-100, 100, -149));

        Triangle triangle4 = new Triangle(new Point3D(-100, 0, -149),
                new Point3D(  0,  -100, -149),
                new Point3D(-100, -100, -149));

        scene.addGeometry(triangle);
        scene.addGeometry(triangle2);
        scene.addGeometry(triangle3);
        scene.addGeometry(triangle4);

        ImageWriter imageWriter = new ImageWriter("Render test", 500, 500, 500, 500);

        Render render = new Render(imageWriter, scene);

        render.renderImage();
        render.printGrid(50);
        render.writeToImage();

    }


    @Test
    public void emmissionTest() throws Exception {
        Scene scene = new Scene("Test3");
        scene.setScreenDistance(50);

        Sphere sphere = new Sphere(50, new Point3D(0.0, 0.0, -150));
        Triangle triangle1 = new Triangle(new Point3D( 100, 0, -149),
                new Point3D(  0, 100, -149),
                new Point3D( 100, 100, -149));

        Triangle triangle2 = new Triangle(new Point3D( 100, 0, -149),
                new Point3D(  0, -100, -149),
                new Point3D( 100,-100, -149));

        Triangle triangle3 = new Triangle(new Point3D(-100, 0, -149),
                new Point3D(  0, 100, -149),
                new Point3D(-100, 100, -149));

        Triangle triangle4 =new Triangle(new Point3D(-100, 0, -149),
                new Point3D(  0,  -100, -149),
                new Point3D(-100, -100, -149));

        sphere.setEmmission(new Color(255, 255, 255));
        triangle1.setEmmission(new Color (255, 255, 255));
        triangle2.setEmmission(new Color (255, 255, 255));
        triangle3.setEmmission(new Color (255, 255, 255));
        triangle4.setEmmission(new Color (255, 255, 255));

        scene.addGeometry(sphere);
        scene.addGeometry(triangle1);
        scene.addGeometry(triangle2);
        scene.addGeometry(triangle3);
        scene.addGeometry(triangle4);

        ImageWriter imageWriter = new ImageWriter("Emmission test", 500, 500, 500, 500);

        Render render = new Render(imageWriter, scene);

        render.renderImage();
        render.printGrid(50);
        render.writeToImage();
    }

    @Test
    public void emmissionTest1() throws Exception {
        Scene scene = new Scene("Test3");
        scene.setScreenDistance(50);

        Sphere sphere = new Sphere(100, new Point3D(0.0, 0.0, -50));
        Triangle triangle = new Triangle(new Point3D( 150, 0, -51),
                new Point3D(  0, 150, -51),
                new Point3D( 150, 150, -51));

        Triangle triangle2 = new Triangle(new Point3D( 150, 0, -51),
                new Point3D(  0, -150, -51),
                new Point3D( 150,-150, -51));

        Triangle triangle3 = new Triangle(new Point3D(-150, 0, -51),
                new Point3D(  0, 150, -51),
                new Point3D(-150, 150, -51));

        Triangle triangle4 = new Triangle(new Point3D(-150, 0, -51),
                new Point3D(  0,  -150, -51),
                new Point3D(-150, -150, -51));

        sphere.setEmmission(new Color (255, 0, 120));
        triangle.setEmmission(new Color (255, 0, 0));
        triangle2.setEmmission(new Color (0, 255, 0));
        triangle3.setEmmission(new Color (255, 0, 255));
        triangle4.setEmmission(new Color (0, 255, 255));

        scene.addGeometry(sphere);
        scene.addGeometry(triangle);
        scene.addGeometry(triangle2);
        scene.addGeometry(triangle3);
        scene.addGeometry(triangle4);



        ImageWriter imageWriter = new ImageWriter("Emmission test1", 500, 500, 500, 500);

        Render render = new Render(imageWriter, scene);

        render.renderImage();
        render.printGrid(50);
        render.writeToImage();
    }

    @Test
    public void shadowTest() throws Exception {

        Scene scene = new Scene("Test4");
        Sphere sphere = new Sphere(500, new Point3D(0.0, 0.0, -800));
        sphere.setShininess(20);
        sphere.setEmmission(new Color(241, 6, 151));

        scene.addGeometry(sphere);

        Triangle triangle1 = new Triangle(new Point3D(  3500,  3500, -1000),
                new Point3D( -3500, -3500, -1000),
                new Point3D(  3500, -3500, -1000));

        Triangle triangle2 = new Triangle(new Point3D(  3500,  3500, -1000),
                new Point3D( -3500,  3500, -1000),
                new Point3D( -3500, -3500, -1000));

        scene.addGeometry(triangle1);
        scene.addGeometry(triangle2);

        scene.addLight(new SpotLight(new Color(200, 200, 200), new Point3D(500, 500, -100),
                new Vector(new Point3D(0, 0, -80)), 0.0001, 0.0001,0.0001));


        ImageWriter imageWriter = new ImageWriter("Shadow test SpotLight1", 500, 500, 500, 500);


        Render render = new Render(imageWriter, scene);

        render.renderImage();
        render.writeToImage();
    }

    @Test
    public void shadowTest1() throws Exception {
        Scene scene = new Scene("Test5");
        Sphere sphere = new Sphere(500, new Point3D(0.0, 0.0, -800));
        sphere.setShininess(20);
        sphere.setEmmission(new Color(100, 100, 100));

        scene.addGeometry(sphere);

        Triangle triangle1 = new Triangle(new Point3D(  -50,  100, -200),
                new Point3D( -700, -500, -500),
                new Point3D(  0, -500, -400));



        scene.addGeometry(triangle1);


        scene.addLight(new SpotLight(new Color(200, 200, 200), new Point3D(-1000, -1000, 300),
                new Vector(new Point3D(100, 100, -80)), 0.0001, 0.0001,0.0001));


        ImageWriter imageWriter = new ImageWriter("Shadow test", 500, 500, 500, 500);

        Render render = new Render(imageWriter, scene);

        render.renderImage();
        render.writeToImage();

    }

    @Test
    public void  spointlight () throws Exception
    {
        Scene scene = new Scene("Test6");
        Sphere sphere = new Sphere( 500, new Point3D(0.0, 0.0, -1000));
        sphere.setEmmission(new Color(241, 6, 151));
        sphere.setShininess(20);
        scene.addGeometry(sphere);

        scene.addLight(new SpotLight(new Color(200, 200, 200), new Point3D(-250, -250, -150),
                new Vector(new Point3D(2, 2, -2)), 0, 0.00001, 0.000005));

        ImageWriter imageWriter = new ImageWriter("spot tese", 500, 500, 500, 500);

        Render render = new Render(imageWriter, scene);

        render.renderImage();
        //render.printGrid(50);
        render.writeToImage();

    }

    @Test
    public void spotLightTest2() throws Exception {//SPOT TEST 2 NOT OK

        Scene scene = new Scene("Test7");
        //scene.setScreenDistance(200);
        Sphere sphere = new Sphere( 500, new Point3D(0.0, 0.0, -1000));
        sphere.setEmmission(new Color(241, 6, 151));
        sphere.setShininess(20);
        scene.addGeometry(sphere);

        Triangle triangle = new Triangle(new Point3D(-125, -225, -260),
                new Point3D(-225, -125, -260),
                new Point3D(-225, -225, -270));

        triangle.setEmmission(new Color(68, 242, 16));

        Triangle triangle1 = new Triangle(new Point3D(  3500,  3500, -1000),
                new Point3D( -3500, -3500, -1000),
                new Point3D(  3500, -3500, -1000));

        Triangle triangle2 = new Triangle(new Point3D(  3500,  3500, -1000),
                new Point3D( -3500,  3500, -1000),
                new Point3D( -3500, -3500, -1000));

        //scene.addGeometry(triangle1);
        //scene.addGeometry(triangle2);

        triangle.setShininess(4);
        scene.addGeometry(triangle);


        scene.addLight(new SpotLight(new Color(200, 200, 200), new Point3D(-250, -250, -150),
                new Vector(new Point3D(2, 2, -2)), 0, 0.00001, 0.000005));

        ImageWriter imageWriter = new ImageWriter("Spot test 2", 500, 500, 500, 500);

        Render render = new Render(imageWriter, scene);

        render.renderImage();
        //render.printGrid(50);
        render.writeToImage();

    }


    @Test
    public void recursiveTest() throws Exception {
        Scene scene = new Scene("Test8");
        scene.setScreenDistance(300);

        Sphere sphere = new Sphere(500, new Point3D(0.0, 0.0, -1000));
        sphere.setShininess(20);
        sphere.setEmmission(new Color(0, 0, 100));
        sphere.setKt(0.5);
        scene.addGeometry(sphere);

        Sphere sphere2 = new Sphere(250, new Point3D(0.0, 0.0, -1000));
        sphere2.setShininess(20);
        sphere2.setEmmission(new Color(100, 20, 20));
        sphere2.setKt(0);
        scene.addGeometry(sphere2);

        scene.addLight(new SpotLight(new Color(255, 100, 100), new Point3D(-200, -200, -150),
                new Vector(new Point3D(2, 2, -3)), 0, 0.00001, 0.000005));

        ImageWriter imageWriter = new ImageWriter("Recursive Test 11", 500, 500, 500, 500);

        Render render = new Render(imageWriter, scene);

        render.renderImage();
        render.writeToImage();
    }


    @Test
    public void recursiveTest2() throws Exception {

        Scene scene = new Scene("Test9");
        scene.setScreenDistance(300);

        Sphere sphere = new Sphere(300, new Point3D(-550, -500, -1000));
        sphere.setShininess(20);
        sphere.setEmmission(new Color(0, 0, 100));
        sphere.setKt(0.5);
        scene.addGeometry(sphere);

        Sphere sphere2 = new Sphere(150, new Point3D(-550, -500, -1000));
        sphere2.setShininess(20);
        sphere2.setEmmission(new Color(100, 20, 20));
        sphere2.setKt(0);
        scene.addGeometry(sphere2);

        Triangle triangle = new Triangle(new Point3D(  1500, -1500, -1500),
                new Point3D( -1500,  1500, -1500),
                new Point3D(  200,  200, -375));

        Triangle triangle2 = new Triangle(new Point3D(  1500, -1500, -1500),
                new Point3D( -1500,  1500, -1500),
                new Point3D( -1500, -1500, -1500));

        triangle.setEmmission(new Color(20, 20, 20));
        triangle2.setEmmission(new Color(20, 20, 20));
        triangle.setKr(1);
        triangle2.setKr(0.5);
        scene.addGeometry(triangle);
        scene.addGeometry(triangle2);

        scene.addLight(new SpotLight(new Color(255, 100, 100),  new Point3D(200, 200, -150),
                new Vector(new Point3D(-2, -2, -3)), 0, 0.00001, 0.000005));

        ImageWriter imageWriter = new ImageWriter("Recursive Test 2", 500, 500, 500, 500);

        Render render = new Render(imageWriter, scene);

        render.renderImage();
        render.writeToImage();

    }

    @Test
    public void recursiveTest3() throws Exception {

        Scene scene = new Scene("Test10");
        scene.setScreenDistance(300);

        Sphere sphere = new Sphere(300, new Point3D(0, 0, -1000));
        sphere.setShininess(20);
        sphere.setEmmission(new Color(0, 0, 100));
        sphere.setKt(0.5);
        scene.addGeometry(sphere);

        Sphere sphere2 = new Sphere(150, new Point3D(0, 0, -1000));
        sphere2.setShininess(20);
        sphere2.setEmmission(new Color(100, 20, 20));
        sphere2.setKt(0);
        scene.addGeometry(sphere2);

        Triangle triangle = new Triangle(new Point3D(  2000, -1000, -1500),
                new Point3D( -1000,  2000, -1500),
                new Point3D(  700,  700, -375));

        Triangle triangle2 = new Triangle(new Point3D(  2000, -1000, -1500),
                new Point3D( -1000,  2000, -1500),
                new Point3D( -1000, -1000, -1500));

        triangle.setEmmission(new Color(20, 20, 20));
        triangle2.setEmmission(new Color(20, 20, 20));
        triangle.setKr(1);
        triangle2.setKr(0.5);
        scene.addGeometry(triangle);
        scene.addGeometry(triangle2);

        scene.addLight(new SpotLight(new Color(255, 100, 100),  new Point3D(200, 200, -150),
                new Vector(new Point3D(-2, -2, -3)), 0, 0.00001, 0.000005));

        ImageWriter imageWriter = new ImageWriter("Recursive Test 3", 500, 500, 500, 500);

        Render render = new Render(imageWriter, scene);

        render.renderImage();
        render.writeToImage();
    }



    @Test
    public void MyScene() throws Exception {
        Camera myCam = new Camera(new Point3D(400,400,1000),new Vector(new Point3D(0,1,0)),new Vector(new Point3D(0,0 ,-1)),new Vector(new Point3D(1,0,0)));

        Scene scene = new Scene("Test4",myCam,new java.awt.Color(15, 15, 70, 233));

        Plane plane = new Plane(new Vector(new Point3D(0,1,0)),new Point3D(  0,  -100, 0));
        plane.setEmmission(new Color(170, 170, 40));
        plane.setShininess(20);
        plane.setKd(1);
        scene.addGeometry(plane);

        Triangle tr1 = new Triangle(new Point3D(  250, -100, -300),
                new Point3D( 250,  -100, -800),
                new Point3D( 0, 200, -550));
        tr1.setEmmission(new Color(255, 221, 122));
        scene.addGeometry(tr1);

        Triangle tr2 = new Triangle(new Point3D(  250, -100, -300),
                new Point3D( -250,  -100, -300),
                new Point3D( 0, 200, -550));
        tr2.setEmmission(new Color(255, 221, 122));
        scene.addGeometry(tr2);

        Triangle tr3 = new Triangle(new Point3D(  250, -100, -300),
                new Point3D( -250,  -100, -300),
                new Point3D( 0, 200, -550));
        tr3.setEmmission(new Color(255, 221, 122));
        scene.addGeometry(tr3);

        Triangle tr4 = new Triangle(new Point3D(  250, -100, -800),
                new Point3D( -250,  -100, -800),
                new Point3D( 0, 200, -550));
        tr4.setEmmission(new Color(255, 221, 122));
        scene.addGeometry(tr4);

        scene.addLight(new SpotLight(new Color(100, 100, 100), new Point3D(1200, 700, -700),new Vector(new Point3D(1000, 800, 300)),
                0, 0.00001,0.000005));

        Sphere sphere = new Sphere(200, new Point3D(1250, 1000, -1500));
        sphere.setShininess(20);
        sphere.setKt(1);
        sphere.setEmmission(new Color(255, 253, 122));
        scene.addGeometry(sphere);

        ImageWriter imageWriter = new ImageWriter("MyScene", 500, 500, 500, 500);


        Render render = new Render(imageWriter, scene);

        render.renderImage();
        render.writeToImage();
    }

    @Test
    public void MyScene2() throws Exception {
        Camera myCam = new Camera(new Point3D(400,400,800),new Vector(new Point3D(0,1,0)),new Vector(new Point3D(0,0 ,-1)),new Vector(new Point3D(1,0,0)));

        Scene scene = new Scene("Test",myCam,new java.awt.Color(116, 200, 255));

        Plane plane = new Plane(new Vector(new Point3D(0,1,0)),new Point3D(  0,  -100, 0));
        plane.setEmmission(new Color(255, 189, 67));
        plane.setShininess(20);
        plane.setKd(1);
        scene.addGeometry(plane);

        Triangle tr1 = new Triangle(new Point3D(  250, -100, -300),
                new Point3D( 250,  -100, -800),
                new Point3D( 0, 200, -550));
        tr1.setEmmission(new Color(255, 221, 122));
        scene.addGeometry(tr1);

        Triangle tr2 = new Triangle(new Point3D(  250, -100, -300),
                new Point3D( -250,  -100, -300),
                new Point3D( 0, 200, -550));
        tr2.setEmmission(new Color(255, 221, 122));
        scene.addGeometry(tr2);

        Triangle tr3 = new Triangle(new Point3D(  250, -100, -300),
                new Point3D( -250,  -100, -300),
                new Point3D( 0, 200, -550));
        tr3.setEmmission(new Color(255, 221, 122));
        scene.addGeometry(tr3);

        Triangle tr4 = new Triangle(new Point3D(  250, -100, -800),
                new Point3D( -250,  -100, -800),
                new Point3D( 0, 200, -550));
        tr4.setEmmission(new Color(255, 221, 122));
        scene.addGeometry(tr4);

        scene.addLight(new PointLight(new Color(100, 100, 100), new Point3D(1200, 700, -700),//new Vector(new Point3D(1000, 800, 300)),
                0, 0.00001,0.000005));

        Sphere sphere = new Sphere(200, new Point3D(1250, 1000, -1500));
        sphere.setShininess(20);
        sphere.setKt(1);
        sphere.setEmmission(new Color(255, 253, 122));
        scene.addGeometry(sphere);

        ImageWriter imageWriter = new ImageWriter("MyScene2", 500, 500, 500, 500);


        Render render = new Render(imageWriter, scene);

        render.renderImage();
        render.writeToImage();
    }
}