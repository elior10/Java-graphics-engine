package Geometries;

import geometries.Plane;
import org.junit.jupiter.api.Test;
import primitives.*;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class PlaneTest {

    @Test
    void getNormal() {
        Plane p1 = new Plane
                (new Point3D(0,0,0)
                ,new Point3D(2,2,0)
                ,new Point3D(4,0,0));
        assertEquals(p1.getNormal(new Point3D()), new Vector(new Point3D(0,0,-1)));

    }

    @Test
    void findIntersections() {
        //the ray is on the plane and same direction. expected => 0
        Ray ray = new Ray(new Point3D(1,1,1),new Vector(new Point3D(1,0,0)));
        Plane p1 = new Plane
                (new Point3D(2,2,1)
                 ,new Point3D(3,0,1)
                 ,new Point3D(2,1,1));
        List<Point3D> L = p1.FindIntersections(ray);
        assertEquals(L.size(),0);

        //the ray is normally going through the plane. expected => 1
        ray = new Ray(new Point3D(1,1,1),new Vector(new Point3D(1,0,0)));
        p1 = new Plane
                (new Point3D(2,2,0)
                        ,new Point3D(2,0,0)
                        ,new Point3D(2,1,1));
        List<Point3D> L1 = p1.FindIntersections(ray);
        assertEquals(L1.size(),1);

        //the ray begin on the plane but not the same direction. expected => 0
        ray = new Ray(new Point3D(2,1,0),new Vector(new Point3D(0,0,1)));
        p1 = new Plane
                (new Point3D(1,1,0)
                        ,new Point3D(2,2,0)
                        ,new Point3D(3,1,0));
        List<Point3D> L2 = p1.FindIntersections(ray);
        assertEquals(L2.size(),0);

        //the ray begin after the plane not same direction. expected => 0
        ray = new Ray(new Point3D(4,1,0),new Vector(new Point3D(1,0,0)));
        p1 = new Plane
                (new Point3D(1,0,0)
                        ,new Point3D(1,2,0)
                        ,new Point3D(1,1,1));
        List<Point3D> L3 = p1.FindIntersections(ray);
        assertEquals(L3.size(),0);
    }
}