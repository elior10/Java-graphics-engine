package Geometries;

import org.junit.jupiter.api.Test;

import geometries.Triangle;
import primitives.*;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class TriangleTest {

    @Test
    void getNormal() {
        Triangle triangle = new Triangle(
                new Point3D(0,0,0),
                new Point3D(2,2,0),
                new Point3D(4,0,0));
        assertEquals(triangle.getNormal(new Point3D()),new Vector(new Point3D(0,0,-1)));

    }

    @Test
    void findIntersections() {
        //the ray goes normally through the triangle. expected => 1
        Triangle trn1 = new Triangle(
                new Point3D(0,0,0),
                new Point3D(2,2,0),
                new Point3D(4,0,0));
        Ray ray = new Ray(new Point3D(0.5,0.49,-1),new Vector(new Point3D(0,0,1)));
        List<Point3D> L = trn1.FindIntersections(ray);
        assertEquals(L.size(),1);

        //the ray goes on the border of the triangle expected => 0
        trn1 = new Triangle(
                new Point3D(0,0,0),
                new Point3D(2,2,0),
                new Point3D(4,0,0));
        ray = new Ray(new Point3D(0,0,-1),new Vector(new Point3D(0,0,1)));
        L = trn1.FindIntersections(ray);
        assertEquals(L.size(),0);

        //the triangle goes through the plane but not the triangle. expected => 0
        trn1 = new Triangle(
                new Point3D(0,0,0),
                new Point3D(2,2,0),
                new Point3D(4,0,0));
        ray = new Ray(new Point3D(-1,0,-1),new Vector(new Point3D(0,0,1)));
        L = trn1.FindIntersections(ray);
        assertEquals(L.size(),0);
    }
}