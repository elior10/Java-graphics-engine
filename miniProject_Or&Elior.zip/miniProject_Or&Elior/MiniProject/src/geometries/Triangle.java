/************** אליאור קליין 329843999; אור ואזנה 318725215 *******/

package geometries;

import primitives.*;
import primitives.Vector;

import java.util.*;
import java.util.List;

public class Triangle extends Plane implements FlatGeometry{
    private Point3D p1;
    private Point3D p2;
    private Point3D p3;
    // private Plane plane; To be continued...
    // ***************** Constructors ********************** //
    public Triangle(Point3D _p1, Point3D _p2, Point3D _p3) {
        super(_p1,_p2,_p3);
        this.p1 = _p1;
        this.p2 = _p2;
        this.p3 = _p3;
    }

    public Triangle(Color color1, Point3D _p1, Point3D _p2, Point3D _p3) {
        super(_p1,_p2,_p3);
        this.setEmmission(color1);
        this.p1 = _p1;
        this.p2 = _p2;
        this.p3 = _p3;
    }

    public Triangle(Triangle triangle1) {
        super(triangle1.get_p1(), triangle1.get_p2(), triangle1.get_p3());
        this.p1 = triangle1.get_p1();
        this.p2 = triangle1.get_p2();
        this.p3 = triangle1.get_p3();
    }

    // ***************** Getters ********************** //
    public Point3D get_p1() {
        return p1;
    }
    public Point3D get_p2() {
        return p2;
    }
    public Point3D get_p3() {
        return p3;
    }

    /********** Functions ***********/
    @Override
    public Vector getNormal(Point3D point) { return N.normalize(); }

    @Override
    public List<Point3D> FindIntersections(Ray ray) {//IN CASE OF JUST ONE POINT!!!!!!!
        List<Point3D> l = super.FindIntersections(ray);
        if(l.size()<1){
            return new ArrayList<>();
        }
        Vector v1 = this.get_p1().subPoint(ray.get_p());
        Vector v2 = this.get_p2().subPoint(ray.get_p());
        Vector v3 = this.get_p3().subPoint(ray.get_p());

        Vector N1 = v1.crossProduct(v2).normalize();
        Vector N2 = v2.crossProduct(v3).normalize();
        Vector N3 = v3.crossProduct(v1).normalize();

        Vector vec = l.get(0).subPoint(ray.get_p());

        double d1 = N1.dotProduct(vec);
        double d2 = N2.dotProduct(vec);
        double d3 = N3.dotProduct(vec);

        if(Util.isZero(d1) || Util.isZero(d2) || Util.isZero(d3)){
            return new ArrayList<>();
        }
        else{
            if (d1>0){
                if(d2>0 && d3>0){
                    return l;
                }
            }
            else if(d2<0 && d3<0){
                return l;
            }
        }
        return new ArrayList<>();
    }
}
