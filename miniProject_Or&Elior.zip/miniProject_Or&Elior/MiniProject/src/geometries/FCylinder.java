package geometries;

import java.awt.*;
import java.awt.Color;
import java.util.ArrayList;
import java.util.LinkedList;

import primitives.*;

public class FCylinder extends Cylinder{


    //NOTE THAT IN CALCULATION WE TREET P1 AS THE `STARTING POINT`
    //OF THE CYLINDER


    private Point3D _p1;

    private Point3D _p2;

    private Vector _direction;
//*************************CONSTRUCTORS***********************//


    public FCylinder(Material material,Color emission,double radius, Point3D p1, Point3D p2) {
        super(material,new primitives.Color(emission).getColor(), radius, new Vector(new Point3D(1,0,0)), p1);

        _direction = new Vector(p2);
        _direction.subtract(new Vector(p1));
        _direction = _direction.normalize();

        if (_direction.length() == 0)
            throw new IllegalArgumentException("direction vector cannot be (0,0,0)");
        _p1 = new Point3D(p1);
        _p2 = new Point3D(p2);
    }


    public FCylinder(FCylinder other) {
        super(other);
        _p1 = new Point3D(other._p1);
        _p2 = new Point3D(other._p2);
        _direction = new Vector(other._direction);
    }

//***************************GETTERS**************************//


    public Vector getDirection() {
        return new Vector(_direction);
    }


    public Point3D getP1() {
        return new Point3D(_p1);
    }


    public Point3D getP2() {
        return new Point3D(_p2);
    }

//**************************OPERATIONS************************//


    private boolean _pointOn(Point3D point) {
        //The vector from p1 (start point) to the given point.
        Vector vector1 = new Vector(point.add(_p1));

        //The vector from p2 (end point) to the given point.
        Vector vector2 = new Vector(point.add(_p2));

        //Checks if the point is on one of the edges of the cylinder
        Vector vector3 = new Vector(point.add(_p1));
        Vector vector4 = new Vector(point.add(_p2));
        double v3_dot_dir = vector3.dotProduct(_direction),
                v4_dot_dir = vector4.dotProduct(_direction);

        if (Util.isZero(v3_dot_dir)) {
            if (Util.usubtract(get_radius(), vector3.length()) >= 0)
                return true;
        }

        if (Util.isZero(v4_dot_dir)) {
            if (Util.usubtract(get_radius(), vector4.length()) >= 0)
                return true;
        }

        if (vector1.dotProduct(_direction) > 0 &&
                vector2.dotProduct(_direction) < 0) {
            return true;
        }
        return false;
    }


    @Override
    public Vector getNormal(Point3D point) {
        if (!_pointOn(point))
            return null;
        return super.getNormal(point);
    }


    @Override
    public ArrayList<Point3D> FindIntersections(Ray ray) {

        ArrayList<Point3D> temp = super.FindIntersections(ray);
        ArrayList<Point3D> toReturn = new ArrayList<Point3D>();

        Plane planeP1 = new Plane(getDirection(), _p1);
        planeP1.setEmmission(new primitives.Color(0,0,0));
        Plane planeP2 = new Plane(getDirection(), _p2);
        planeP2.setEmmission(new primitives.Color(0,0,0));

        java.util.List<Point3D> temp1 = planeP1.FindIntersections(ray);
        java.util.List<Point3D> temp2 = planeP2.FindIntersections(ray);

        for (Point3D point1 : temp1) {
            if (point1.distance(_p1) <= get_radius())
                toReturn.add(point1);
        }

        for (Point3D point2 : temp2) {
            if (point2.distance(_p2) <= get_radius())
                toReturn.add(point2);
        }


        for (Point3D p : temp) {
            if (_pointOn(p))
                toReturn.add(p);
        }
        return toReturn;
    }

    public  void set_shininess(int n){
        Material m = getMaterial();
        m.setN(n);
        setMaterial(m);
    }
}