/************** אליאור קליין 329843999; אור ואזנה 318725215 *******/

package geometries;


import primitives.*;

import java.util.ArrayList;
import java.util.List;

public class Sphere extends RadialGeometry {
    private Point3D center;
    // ***************** Constructors ********************** //

    public Sphere(double radius1, Point3D center) {
        super(radius1);
        this.center = center;
    }

    public Sphere(Color color1, double radius1, Point3D center) {
        super(radius1);
        this.setEmmission(color1);
        this.center = center;
    }

    // ***************** Getters ********************** //

    public Point3D getCenter() {
        return center;
    }

    /************** Functions *******/
    @Override
    public Vector getNormal(Point3D point) {
        return new Vector(point.subPoint(getCenter())).normalize();
    }

    @Override
    public List<Point3D> FindIntersections(Ray ray) {
        Vector u = this.getCenter().subPoint(ray.get_p());
        double Tm = ray.get_direction().dotProduct(u);
        double d = Math.sqrt(Util.usubtract(Math.pow(u.length(),2),Math.pow(Tm,2)));

        double dCheck = Util.usubtract(d, this.get_radius());
        if (dCheck>0 && !Util.isZero(dCheck)){
            return new ArrayList<>();
        }
        else{
            double Th = Math.sqrt(Util.usubtract(Math.pow(this.get_radius(),2),Math.pow(d,2)));
            double T1 = Util.uadd(Tm,Th);
            List<Point3D> l = new ArrayList<>();
            if (T1>=1){
                l.add(ray.get_p().PointAddVec(ray.get_direction().scale(T1)));
            }
            double T2 = Util.usubtract(Tm,Th);
            if (T2>=1 && Th != 0){
                l.add(ray.get_p().PointAddVec(ray.get_direction().scale(T2)));
            }
            return l;
        }
    }
}
