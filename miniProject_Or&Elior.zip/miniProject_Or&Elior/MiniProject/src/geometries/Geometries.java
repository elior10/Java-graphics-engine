package geometries;
import primitives.Point3D;
import primitives.Ray;

import java.util.ArrayList;
import java.util.List;

public class Geometries implements Intersectable {
    private List<Geometry> geometries;

    // ***************** Getters/Setters ********************** //
    public List<Geometry> getGeometries() {return geometries;}
    public void setGeometries(List<Geometry> geometries) {this.geometries = geometries;}

    // ***************** Constructors ********************** //
    public Geometries(){geometries = new ArrayList<>();}
    public Geometries(List<Geometry> geometries1 ){geometries = geometries1;}
    public Geometries(Geometries geo){ geometries = geo.geometries;}

    // ***************** Functions ********************** //
    public void addGeo(Geometry geo){geometries.add(geo);}
    public void addGeoS(List<Geometry> geo){geometries.addAll(geo);}
    public void deleteGeo(Geometry geo){geometries.remove(geo);}


    public List<Point3D> findIntersections(Ray ray) throws Exception {
        List<Point3D> myL = new ArrayList<>();
        for (Geometry var: geometries) {
            myL.addAll(var.FindIntersections(ray));
        }
        return myL;
    }
}
