package geometries;
public interface FlatGeometry { } // Marker interface