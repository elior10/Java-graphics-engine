/************** אליאור קליין 329843999; אור ואזנה 318725215 *******/

package geometries;

import primitives.Color;
import primitives.Material;
import primitives.Point3D;
import primitives.Vector;

import java.awt.*;

public abstract class RadialGeometry extends Geometry {

    protected double radius;

    /********** Constructors ***********/
    public RadialGeometry(double radius1) {
        radius = radius1;
    }

    public RadialGeometry(RadialGeometry other) {
        radius = other.get_radius();
    }

    public RadialGeometry(Material material, Color emmission, double radius) {
        setMaterial(material);
        setEmmission(emmission);
        if (radius <= 0) {
            throw new IllegalArgumentException("A radius has to be positive");
        }

        this.radius = radius;
    }

    /********** Getters/Setters ***********/
    public double get_radius() {
        return radius;
    }

}
