
package geometries;

import java.awt.*;
import java.awt.Color;
import java.util.ArrayList;

import primitives.*;
import primitives.Util.*;

/**
     * Represents an infinite cylinder in the 3D space.
     * That is, the cylinder does not have a length.
     * @author orycohen
     */
    public class Cylinder extends RadialGeometry {

        /**
         * Represents the direction of the cylinder
         */
        private Vector _direction;
        /**
         * A center point in the cylinder
         */
        private Point3D _point;

//*************************CONSTRUCTORS***********************//

        /**
         * constructor for a new Cylinder object
         * @param radius the radius of the cylinder
         * @param direction the direction of the cylinder
         * @param emission the emission color of the cylinder
         * @param material Represents what kind of material this geometry is
         * in terms of diffusion, specularity and shininess.
         * @throws Exception in case of a negative radius
         */
        public Cylinder(Material material, Color emission, double radius, Vector direction, Point3D point) {
            super(material,new primitives.Color(emission), radius);
            if (direction.length() == 0)
                throw new IllegalArgumentException("direction vector cannot be (0,0,0)");

            //We need to normalize the vector for later calculations to be correct.
            _direction = direction.normalize();
            _point = new Point3D(point);
        }

        /**
         * copy constructor for a cylinder object to be deep copied
         * @param other the object being copied
         */
        public Cylinder(Cylinder other) {
            super(other);
            if(other != null){
                _direction = other._direction.normalize();
                _point = new Point3D(other._point);
            }

        }

//************************ADMINISTRATION**********************//

        /**
         * checks if 'this' object is equal to another one
         */
        @Override
        public boolean equals(Object obj) {
            if(obj == null || !(obj instanceof Cylinder))
                return false;
            if (this == obj)
                return true;
            Cylinder other = (Cylinder)obj;

            //the two vectors needs to be in the same direction,
            //but not necessary to have the same length.
            return super.equals(other) &&
                    _direction.crossProduct(other._direction).equals(new Vector(new Point3D(0,0,0))) &&
                    _point.equals(other._point);

        }

        @Override
        public String toString() {
            return "point: "      + _point +
                    " direction: " + _direction +
                    ", radius: "   + get_radius();
        }

//***************************GETTERS**************************//

        /**
         * Function to get the direction of the cylinder
         * @return a new Vector that represents the direction of the cylinder
         */
        public Vector getDirection() {
            return new Vector(_direction);
        }

        /**
         * Function to get a center point in the cylinder
         * @return a new Point3D that represents the
         * center of the cylinder
         */
        public Point3D getPoint() {
            return new Point3D(_point);
        }

//**************************OPERATIONS************************//


        /**
         * returns the normal to the cylinder in a given point
         * This function uses linear algebra calculations.
         */
        @Override
        public Vector getNormal(Point3D point) {
            //The vector from the point of the cylinder to the given point
            Vector vector1 = point.subPoint(getPoint());

            //We need the projection to multiply the _direction unit vector
            double projection = vector1.dotProduct(getDirection());

            Vector vector2 = getDirection();
            vector2.scale(projection);

            //This vector is orthogonal to the _direction vector.
            Vector check = new Vector(vector1);
            check.subtract(vector2);

            return check.normalize();
        }

        /**
         * Function for finding intersections points with an infinite
         * cylinder.
         * @param ray The ray that we check if it intersects the cylinder.
         * @return A list of intersection points, if any.
         */
        @Override
        public ArrayList<Point3D> FindIntersections(Ray ray) {
            ArrayList<Point3D> toReturn = new ArrayList<Point3D>();

            Point3D P = ray.get_p();

            Vector V = ray.get_direction(),
                    Va = getDirection(),
                    DeltaP = P.subPoint(getPoint()),
                    temp_for_use1, temp_for_use2, temp1,temp2,temp3;

            double V_dot_Va = V.dotProduct(Va),
                    DeltaP_dot_Va = DeltaP.dotProduct(Va);

            temp_for_use1 = new Vector(V);
            temp1 = new Vector(Va);
            temp1.scale(V_dot_Va);
            temp_for_use1.subtract(temp1);

            //temp_for_use2 = DeltaP.subtract(Va.scale(DeltaP_dot_Va));
            temp_for_use2 = new Vector(DeltaP);
            temp1 = new Vector(Va);
            temp1.scale(DeltaP_dot_Va);
            temp_for_use2.subtract(temp1);

            double A = temp_for_use1.dotProduct(temp_for_use1);
            // double B = 2*V.subtract(Va.scale(V_dot_Va)).dotProduct(DeltaP.subtract(Va.scale(DeltaP_dot_Va)));
            temp1 = new Vector(V);
            temp2 = new Vector(Va);
            temp2.scale(V_dot_Va);
            temp1.subtract(temp2);
            temp2 = new Vector(DeltaP);
            temp3 = new Vector(Va);
            temp3.scale(DeltaP_dot_Va);
            temp2.subtract(temp3);
            double B = 2*temp1.dotProduct(temp2);

            double C = temp_for_use2.dotProduct(temp_for_use2) - get_radius() * get_radius();
            double desc = Util.usubtract(B * B, 4 * A * C);

            if (desc < 0) {//No solution
                return toReturn;
            }

            double t1 = (-B+Math.sqrt(desc))/(2*A),
                    t2 = (-B-Math.sqrt(desc))/(2*A);

            if (desc == 0) {//One solution
                if (-B/(2*A) < 0)
                    return toReturn;
                temp1 = new Vector(V);
                temp1.scale(-B/(2*A));
                Point3D tempP = new Point3D(P);
                tempP.add(temp1.getHead());
                //toReturn.add(new Vector(P.add(V.scale(-B/(2*A)).getHead())).getHead());
                toReturn.add(new Vector(tempP).getHead());
                return toReturn;
            }
            else if (t1 < 0 && t2 < 0){
                return toReturn;
            }
            else if (t1 < 0 && t2 > 0) {
                //toReturn.add(new Vector(P.add(V.scale(t2).getHead())).getHead());

                temp1 = new Vector(V);
                temp1.scale(t2);
                Point3D tempP = new Point3D(P);
                tempP.add(temp1.getHead());
                toReturn.add(new Vector(tempP).getHead());
                return toReturn;
            }
            else if (t1 > 0 && t2 < 0) {
                //toReturn.add(new Vector(P.add(V.scale(t1).getHead())).getHead());

                temp1 = new Vector(V);
                temp1.scale(t1);
                Point3D tempP = new Point3D(P);
                tempP.add(temp1.getHead());
                toReturn.add(new Vector(tempP).getHead());
                return toReturn;
            }
            else {
                //toReturn.add(new Vector(P.add(V.scale(t1).getHead())).getHead());

                temp1 = new Vector(V);
                temp1.scale(t1);
                Point3D tempP = new Point3D(P);
                tempP.add(temp1.getHead());
                toReturn.add(new Vector(tempP).getHead());

                //toReturn.add(new Vector(P.add(V.scale(t2).getHead())).getHead());

                temp1 = new Vector(V);
                temp1.scale(t2);
                Point3D tempP2 = new Point3D(P);
                tempP2.add(temp1.getHead());
                toReturn.add(new Vector(tempP2).getHead());

                return toReturn;
            }
        }

    }

