/************** אליאור קליין 329843999; אור ואזנה 318725215 *******/

package geometries;

import primitives.*;
import primitives.Vector;

import java.util.*;

public class Plane extends Geometry implements FlatGeometry{
    protected Vector N;
    protected Point3D point;
    // ***************** Constructors ********************** //
    public Plane(Vector n, Point3D _q) {
        this.N = n;
        this.point = _q;
    }

    public Plane(Plane pln) {
        this.N = pln.get_N();
        this.point = pln.get_point();
    }

    public Plane(Point3D a, Point3D b, Point3D c){
        point = a;
        Vector v1 = a.subPoint(b);
        Vector v2 = a.subPoint(c);
        N = v1.crossProduct(v2).normalize();
    }

    public Plane(Color color1, Point3D a, Point3D b, Point3D c){
        this.setEmmission(color1);
        point = a;
        Vector v1 = a.subPoint(b);
        Vector v2 = a.subPoint(c);
        N = v1.crossProduct(v2).normalize();
    }


    public Plane(){}

    // ***************** Getters ********************** //
    public Vector get_N() {
        return N;
    }
    public Point3D get_point() {
        return point;
    }

    /********** Functions ***********/
    @Override
    public Vector getNormal(Point3D point) {
        return get_N().normalize();// maybe already normalized?
    }

    @Override
    public List<Point3D> FindIntersections(Ray ray) {
        Vector n = this.get_N();
        Point3D p = this.get_point();

        if(Util.isZero(n.dotProduct(ray.get_direction()))){//THE VECTOR IS PARALlEL TO THE PLANE
            /*if (Util.isZero(n.dotProduct(p.subPoint(ray.get_p())))) {
                //THE RAY IS INCLUDED TO THE PLANE! RETURN INFINITE NUMBER OF POINTS??
                return null;
            }*/
            return new ArrayList<>();
        }
        else{
            double t = Util.uscale((-n.dotProduct(ray.get_p().subPoint(p))),1/n.dotProduct(ray.get_direction()));

            if (t>=1) {
                List<Point3D> l = new ArrayList<>();
                l.add(ray.get_p().PointAddVec(ray.get_direction().scale(t)));

                return l;
            }
            else{
                List<Point3D> l = new ArrayList<>();
                return l;
            }
        }
    }
}
