/************** אליאור קליין 329843999; אור ואזנה 318725215 *******/

package primitives;

import static primitives.Util.*;

public class Ray {
    private Point3D _p;
    private Vector _direction;

    /************** Constructors *******/
    public Ray(Point3D _p, Vector _direction) {
        this._p = _p;
        this._direction = _direction.normalize();
    }

    public Ray(){}

    public Ray(Ray ray1){
        _p = ray1.get_p();
        _direction = ray1.get_direction();
    }

    /************** Getters/Setters *******/
    public Point3D get_p(){
        return _p;
    }

    public Vector get_direction(){
        return _direction;
    }

    /*************** Admin *****************/
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null) return false;
        if (!(obj instanceof Ray)) return false;
        Ray obj1 = (Ray)obj;
        return get_p().equals(obj1.get_p()) && get_direction().equals(obj1.get_direction());
    }

    @Override
    public String toString() {
        return "Ray:\nStarting point: " + get_p().toString() + "\nVector:" + get_direction().toString();
    }
}
