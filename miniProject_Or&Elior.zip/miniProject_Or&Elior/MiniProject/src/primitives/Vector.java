/************** אליאור קליין 329843999; אור ואזנה 318725215 *******/

package primitives;

import static primitives.Util.uadd;

public class Vector
{
    public static final Point3D ZeroVector=new Point3D();
    private Point3D head;
    // ***************** Constructors ********************** //
    public Vector(Point3D head)
    {
        /*try {
            if (!head.equals(ZeroVector)) {
                this.setHead(head);
            } else {
                throw new Error("VECTOR ZERO!");
            }
        }
        catch (IllegalArgumentException e){
            throw new IllegalArgumentException(e.getMessage());
        }*/
        this.setHead(head);
    }

    public Vector(Vector vec){
        head = vec.getHead();
    }

    // ***************** Getters/Setters ********************** //
    public Point3D getHead() {
        return head;
    }
    public void setHead(Point3D head) {
        this.head = head;
    }

    public static Point3D getZeroVector() {
        return ZeroVector;
    }

    /*************** Admin *****************/
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null) return false;
        if (!(obj instanceof Vector)) return false;
        Vector obj1 = (Vector)obj;
        return getHead().equals(obj1.getHead());
    }

    @Override
    public String toString() {
        return getHead().toString();
    }

    // ***************** Operations ******************** //



    public Vector add(Vector other){
        return new Vector(this.getHead().add(other.getHead()));
    }

    public Vector subtract(Vector other){
        return new Vector(this.getHead().subtract(other.getHead()));
    }

    public Vector scale(double a){
        return new Vector(this.getHead().scale(a));
    }

    public double dotProduct(Vector vect)
    {
         double a = this.getHead().getX().multiply(vect.getHead().getX()).get();
         double b = this.getHead().getY().multiply(vect.getHead().getY()).get();
         double c = this.getHead().getZ().multiply(vect.getHead().getZ()).get();
         return  uadd(a, uadd(b, c));
    }

    public  Vector crossProduct(Vector other)
    {
        Coordinate x=new Coordinate((this.getHead().getY().multiply(other.getHead().getZ())).subtract(this.getHead().getZ().multiply(other.getHead().getY())));
        Coordinate y=new Coordinate((this.getHead().getZ().multiply(other.getHead().getX())).subtract(this.getHead().getX().multiply(other.getHead().getZ())));
        Coordinate z=new Coordinate((this.getHead().getX().multiply(other.getHead().getY())).subtract(this.getHead().getY().multiply(other.getHead().getX())));
        Vector v=new Vector(new Point3D(x,y,z));
        return v;
    }
    public double length()
    {
        double x=this.getHead().getX()._coord;
        double y=this.getHead().getY()._coord;
        double z=this.getHead().getZ()._coord;
        return Math.sqrt(Util.uadd(Util.uadd(Util.uscale(x, x), Util.uscale(y, y)), Util.uscale(z, z)));
    }

    public Vector normalize(){ return new Vector(this.getHead()).scale(1/length()); }

}
