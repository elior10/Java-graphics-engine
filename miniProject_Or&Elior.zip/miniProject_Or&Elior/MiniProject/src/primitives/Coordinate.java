/************** אליאור קליין 329843999; אור ואזנה 318725215 *******/

package primitives;

import static primitives.Util.*;

public final class Coordinate {
	//private static final double EPSILON = 0.0000001;
	protected double _coord;

	public static final Coordinate ZERO = new Coordinate(0.0);
	
	/********** Constructors ***********/
	public Coordinate(double coord) {
		// if it too close to zero make it zero
		_coord = alignZero(coord);
	}
	public Coordinate(){}

	public Coordinate(Coordinate other) {
		_coord = new Coordinate(other._coord)._coord;
	}

	/************** Getters/Setters *******/
	public double get() {
		return (new Coordinate(_coord))._coord;
	}
	public void set_coord(double d) { this._coord = d; }

	/*************** Admin *****************/
	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (!(obj instanceof Coordinate)) return false;
		return usubtract(_coord, ((Coordinate)obj)._coord) == 0.0;
	}

	@Override
	public String toString() {
		return "" + _coord;
	}

	/************** Operations ***************/
	public Coordinate subtract(Coordinate other) {
		return new Coordinate(usubtract(_coord, other._coord));
	}

	public Coordinate add(Coordinate other) {
		return new Coordinate(uadd(_coord, other._coord));
	}
	
	public Coordinate scale(double num) {
		return new Coordinate(uscale(_coord, num));
	}

	public Coordinate multiply(Coordinate other) { return new Coordinate(uscale(_coord, other._coord)); }

}
