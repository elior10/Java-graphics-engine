/************** אליאור קליין 329843999; אור ואזנה 318725215 *******/

package primitives;

import java.util.Objects;

public class Point2D {
    private Coordinate x;
    private Coordinate y;

    /********** Constructors ***********/
    public Point2D(Coordinate x, Coordinate y) {
        this.setX(x);
        this.setY(y);
    }

    public Point2D() {
        this.setX(Coordinate.ZERO);
        this.setY(Coordinate.ZERO);
    }

    public Point2D(Point2D other) {
        this.setX(other.getX());
        this.setY(other.getY());
    }

    /************** Getters/Setters *******/
    public Coordinate getX() {
        return x;
    }

    public void setX(Coordinate x) {
        this.x = x;
    }

    public Coordinate getY() {
        return y;
    }

    public void setY(Coordinate y) {
        this.y = y;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Point2D point2D = (Point2D) o;
        return getX().equals(point2D.getX()) &&
                getY().equals(point2D.getY());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getX(), getY());
    }

    /*************** Admin *****************/


    @Override
    public String toString() {
        return getX().toString() +","+ getY().toString();
    }

    /************** Operations ***************/
    public Point2D subtract(Point2D other) {
        return new Point2D
                (getX().subtract(other.getX())
                        , getY().subtract(other.getY()));
    }

    public Point2D add(Point2D other) {
        return new Point2D
                (getX().add(other.getX())
                        , getY().add(other.getY()));
    }

    public Point2D scale(double num) {
        return new Point2D
                (getX().scale(num)
                        , getY().scale(num));
    }


}