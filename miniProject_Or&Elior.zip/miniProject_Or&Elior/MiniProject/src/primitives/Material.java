package primitives;

public class Material {
    private double n; // Refraction index
    private double Ks; // Specular attenuation coefficient
    private double Kt; // Refraction coefficient (1 for transparent)
    private double Kd; // Diffusion attenuation coefficient
    private double Kr; // Reflection coefficient (1 for mirror)

    // ***************** Constructors ********************** //
    public Material() {
        n = 1;
        Ks = 1;
        Kt = 0;
        Kd = 1;
        Kr = 0;
    }



    public Material(Material material){
        n = material.getN();
        Ks = material.getKs();
        Kt = material.getKt();
        Kd = material.getKd();
        Kr = material.getKr();
    }

    // ***************** Getters/Setters ********************** //
    public void setN (double n){this.n = n;}
    public void setKs(double Ks){this.Ks = Ks;}
    public void setKt(double Kt){this.Kt = Kt;}
    public void setKd(double Kd){this.Kd = Kd;}
    public void setKr(double Kr){this.Kr = Kr;}
    public double getN(){return n;}
    public double getKs(){return Ks;}
    public double getKt(){return Kt;}
    public double getKd(){return Kd;}
    public double getKr(){return Kr;}

}