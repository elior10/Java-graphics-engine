/************** אליאור קליין 329843999; אור ואזנה 318725215 *******/

package primitives;

import java.util.Objects;

import static java.lang.Math.pow;
import static java.lang.Math.sqrt;

public final class Point3D extends Point2D {
    private Coordinate z;

    /********** Constructors ***********/
    public Point3D(Coordinate x, Coordinate y, Coordinate z) {
       super(x, y);
       this.setZ(z);
    }
    public Point3D() {
        super();
        this.setZ(Coordinate.ZERO);
    }
    public Point3D(Point3D other) {
        super(other);
        this.setZ(other.getZ());
    }
    public Point3D(double x, double y, double z) {
        this(new Coordinate(x),new Coordinate(y),new Coordinate(z));
    }
    /************** Getters/Setters *******/
    public Coordinate getZ() {
        return new Coordinate(z);
    }

    public void setZ(Coordinate z) {
        this.z = new Coordinate(z);
    }

    /*************** Admin *****************/

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Point3D point3D = (Point3D) o;
        return getZ().equals(point3D.getZ());
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), getZ());
    }


    @Override
    public String toString()
    {
        return super.toString() + ","+ getZ();
    }

    /************** Operations ***************/
    public Point3D subtract(Point3D other) {
        return new Point3D
                (getX().subtract(other.getX()), getY().subtract(other.getY()), getZ().subtract(other.getZ()));
    }

    public Point3D add(Point3D other) {
        return new Point3D
                (getX().add(other.getX()), getY().add(other.getY()), getZ().add(other.getZ()));
    }

    public Point3D scale(double num) {
        return new Point3D
                (getX().scale(num), getY().scale(num), getZ().scale(num));
    }

    /************** Functions ***************/
    public double distance(Point3D other) {
        return sqrt(pow(getX().get() - other.getX().get(),2 ) +
                pow(getY().get() - other.getY().get(),2 ) +
                pow(getZ().get() - other.getZ().get(),2 ) );
    }

    public Vector subPoint(Point3D other){
        Vector h=new Vector(new Point3D(this.subtract(other)));
        return new Vector(h);
    }

    public Point3D PointAddVec(Vector vect)
    {
        return new Point3D(add(vect.getHead()));
    }


}
