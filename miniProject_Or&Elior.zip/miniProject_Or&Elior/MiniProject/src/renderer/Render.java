package renderer;

import Elements.LightSource;
import geometries.FlatGeometry;
import geometries.Geometry;
import primitives.Point3D;
import primitives.Ray;
import primitives.Vector;
import scene.Scene;

import java.awt.*;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class Render
{
    private Scene _scene;
    private ImageWriter _imageWriter;
    private final int RECURSION_LEVEL = 3;

    // ***************** Constructors ********************** //
    public Render(ImageWriter imageWriter, Scene scene)
    {
        _scene = scene;
        _imageWriter = imageWriter;
    }
    // ***************** Functions ********************** //
    public void writeToImage(){
        _imageWriter.writeToimage();
    }

    public void printGrid(int interval){
        double height = _imageWriter.getHeight();
        double width = _imageWriter.getWidth();

        for (int i = 0; i < height; i++){
            for (int j = 0; j < width; j++){

                if (i % interval == 0 || j % interval == 0)
                    _imageWriter.writePixel(j, i, new Color(255, 255, 255));

            }
        }
    }

    public void renderImage() throws Exception {
        for (int i = 0 ; i < _imageWriter.getWidth(); i++){
            for (int j = 0; j < _imageWriter.getHeight(); j++){
                Ray ray=_scene.getCamera().constructRayThroughPixel(_imageWriter.getNx(),
                        _imageWriter.getNy(),j,i,_scene.getScreenDistance()
                        ,_imageWriter.getWidth()
                        ,_imageWriter.getHeight());
                Map<Geometry, List<Point3D>> intersectionPoints = getSceneRayIntersections(ray);
                if(intersectionPoints.isEmpty()){
                    _imageWriter.writePixel(j,i,_scene.getBackground());
                }
                else{
                    Entry<Geometry, Point3D> closestPoint = getClosestPoint(intersectionPoints).entrySet().iterator().next();
                    _imageWriter.writePixel(j,i,calcColor(closestPoint.getKey(),closestPoint.getValue(),ray));
                }
            }
        }
    }

    private Entry<Geometry, Point3D> findClosesntIntersection(Ray ray) throws Exception {
        Map<Geometry, List<Point3D>> intersectionPoints = getSceneRayIntersections(ray);

        if (intersectionPoints.size() == 0)
            return null;

        Map<Geometry, Point3D> closestPoint = getClosestPoint(intersectionPoints);
        Entry<Geometry, Point3D> entry = closestPoint.entrySet().iterator().next();
        return entry;
    }

    private Color calcColor(Geometry geometry, Point3D point) throws Exception {
        Color emissionLight = geometry.getEmmission().getColor();
        Color ambientLight = _scene.getAmbientLight().getIntensity().getColor();

        return  addColors(emissionLight,ambientLight);
    }

    private boolean occluded(LightSource light, Point3D point, Geometry geometry) throws Exception {
        Vector lightDirection = light.getL(point);
        lightDirection = lightDirection.scale(-1);

        Point3D geometryPoint = new Point3D(point);

        Vector epsVector = new Vector(geometry.getNormal(point));
        epsVector=epsVector.scale(2);
        geometryPoint = geometryPoint.PointAddVec(epsVector);

        Ray lightRay = new Ray(geometryPoint, lightDirection);
        Map <Geometry,List<Point3D>> intersectionPoint = getSceneRayIntersections(lightRay);

        if (geometry instanceof FlatGeometry){
            intersectionPoint.remove(geometry);
        }

        if (geometry.getMaterial().getKt() >= 0.5) {
            intersectionPoint.remove(geometry);
        }

        return !intersectionPoint.isEmpty();
    }

    private Color calcColor(Geometry geometry, Point3D point, Ray inRay) throws Exception {
        return calcColor(geometry, point, inRay, 0);
    }

    private Color calcColor(Geometry geometry, Point3D point,Ray inRay, int level) throws Exception {
        if (level == RECURSION_LEVEL){
            return new Color(0, 0, 0);
        }

        Color ambientLight = _scene.getAmbientLight().getIntensity().getColor();
        Color emissionLight = geometry.getEmmission().getColor();

        Color inherentColors = addColors(ambientLight, emissionLight);

        Iterator<LightSource> lights = _scene.getLightsIterator();

        Color lightReflected = new Color(0, 0, 0);

        while (lights.hasNext()){

            LightSource light = lights.next();

            if (!occluded(light, point, geometry)){

                Color lightIntensity = light.getIntensity(point).getColor();


                Color lightDiffuse = calcDiffusiveComp(geometry.getMaterial().getKd(),
                        geometry.getNormal(point),
                        light.getL(point),
                        lightIntensity);


                Color lightSpecular = calcSpecularComp(geometry.getMaterial().getKs(),
                        _scene.getCamera().getp0().subPoint(point),
                        geometry.getNormal(point),
                        light.getL(point),
                        geometry.getShininess(),
                        lightIntensity);

                lightReflected = addColors(lightDiffuse, lightSpecular);
            }
        }

        Color I0 = addColors(inherentColors, lightReflected);

        Ray reflectedRay = constructReflectedRay(geometry.getNormal(point), point, inRay);
        Entry<Geometry, Point3D> reflectedEntry = findClosesntIntersection(reflectedRay);
        Color reflected = new Color(0, 0, 0);
        if (reflectedEntry != null){
            reflected = calcColor(reflectedEntry.getKey(), reflectedEntry.getValue(), reflectedRay, level + 1);
            double kr = geometry.getMaterial().getKr();
            reflected = new Color ((int)(reflected.getRed() * kr), (int)(reflected.getGreen() * kr),(int)(reflected.getBlue() * kr));
        }

        Ray refractedRay = constructRefractedRay(geometry, point, inRay);
        Entry<Geometry, Point3D> refractedEntry = findClosesntIntersection(refractedRay);
        Color refracted = new Color(0, 0, 0);
        if (refractedEntry != null){
            refracted = calcColor(refractedEntry.getKey(), refractedEntry.getValue(), refractedRay, level + 1);
            double kt = geometry.getMaterial().getKt();
            refracted = new Color ((int)(refracted.getRed() * kt), (int)(refracted.getGreen() * kt),(int)(refracted.getBlue() * kt));
        }

        Color envColors = addColors(reflected, refracted);

        Color finalColor = addColors(envColors, I0);

        return finalColor;
    }

    private Ray constructRefractedRay(Geometry geometry, Point3D point, Ray inRay) throws Exception {

        Vector normal = geometry.getNormal(point);
        normal = normal.scale(-2);
        point = point.PointAddVec(normal);

        if (geometry instanceof FlatGeometry){
            return new Ray (point, inRay.get_direction());
        } else {
            return new Ray (point, inRay.get_direction());
        }

    }

    private Ray constructReflectedRay(Vector normal, Point3D point, Ray inRay) throws Exception {

        Vector l = inRay.get_direction();
        l = l.normalize();

        normal = normal.scale(-2 * l.dotProduct(normal));
        l = l.add(normal);

        Vector R = new Vector(l);
        R = R.normalize();

        point = point.PointAddVec(normal);

        Ray reflectedRay = new Ray(point, R);

        return reflectedRay;
    }

    private Color calcSpecularComp(double ks, Vector v, Vector normal,
                                   Vector l, double shininess, Color lightIntensity) throws Exception {
        Vector r = new Vector(normal);
        r = r.scale(-2*normal.dotProduct(l));
        r = r.add(l);
        r = r.normalize();
        v = v.normalize();
        double specular = ks*Math.pow(r.dotProduct(v),shininess);
        if(specular < 0)
        {specular *= -1;}
        return new Color((int)(lightIntensity.getRed()* specular)%256 ,
                (int)(lightIntensity.getGreen()*specular)%256,
                (int)(lightIntensity.getBlue()*specular)%256);
    };

    private Color calcDiffusiveComp(double kd, Vector normal, Vector l,
                                    Color lightIntensity)
    {
        double dif = Math.abs(kd*normal.dotProduct(l));

        return new Color((int)(lightIntensity.getRed()*dif)%256 ,
                (int)(lightIntensity.getGreen()*dif)%256,
                (int)(lightIntensity.getBlue()*dif)%256);
    }

    private Map<Geometry, Point3D> getClosestPoint(Map<Geometry,List<Point3D>> intersectionPoints){

        double distance = Double.MAX_VALUE;
        Point3D P0 = new Point3D(_scene.getCamera().getp0());
        Point3D minDistancPoint = null;
        Geometry minDistancGeometry = null;

        for(Entry<Geometry, List<Point3D>> entry : intersectionPoints.entrySet()){
            for (Point3D point: entry.getValue())
                if(P0.distance(point) < distance){
                    minDistancPoint = new Point3D(point);
                    minDistancGeometry = entry.getKey();
                    distance = P0.distance(point);
                }
        }

        Map<Geometry,Point3D> minDistancMap=new HashMap<>();
        minDistancMap.put(minDistancGeometry,minDistancPoint);
        return minDistancMap;
    }

    private Map<Geometry, List<Point3D>> getSceneRayIntersections(Ray ray) throws Exception {
        Iterator<Geometry> geometryIterator = _scene.getGeometriesIterator();
        Map<Geometry, List<Point3D>> intersectionPoint = new HashMap<Geometry, List<Point3D>>();

        while(geometryIterator.hasNext()){
            Geometry geometry = geometryIterator.next();
            List<Point3D> geomtryIntersectionPoint = geometry.FindIntersections(ray);
            if (!geomtryIntersectionPoint.isEmpty())
                intersectionPoint.put(geometry,geomtryIntersectionPoint);
        }
        return intersectionPoint;
    }

    private Color addColors(Color a, Color b){

        int red = a.getRed() + b.getRed();
        if (red > 255) red = 255;

        int green = a.getGreen() + b.getGreen();
        if (green > 255) green = 255;

        int blue = a.getBlue() + b.getBlue();
        if (blue > 255) blue = 255;

        Color x = new Color (red, green, blue);

        return x;
    }

}