package Elements;

import primitives.Point3D;
// קרדיט ליוחנן חייק ולעידו הראל

import primitives.Vector;
import primitives.Color;
import java.awt.*;

public class PointLight extends Light implements LightSource {
    Point3D position;
    double Kc, Kl, Kq;
    // ***************** Constructors ********************** //
    public PointLight(Color color1, Point3D position1,
                      double kc, double kl, double kq){
        color = color1;
        position = position1;
        Kc = kc;
        Kl = kl;
        Kq = kq;
    }
    // ***************** Getters/Setters ********************** //
    public Color getIntensity(){return color;}

    @Override
    public Color getIntensity(Point3D point) throws Exception {
        Color I0 = this.getIntensity();
        double d = position.distance(point);
        double Il = 1/(Kc * (Kl * d) * (Kq*Math.pow(d,2)));
        if(Il > 1) {Il = 1;}
        return new Color(I0.scale(Il));
    }

    public Vector getL(Point3D point) throws Exception {
        Vector l = point.subPoint(position);
        l = l.normalize();

        return l;
    }
}