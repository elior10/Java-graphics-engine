package Elements;

import java.awt.*;
import primitives.Color;
public class AmbientLight extends Light {

    double Ka;

    // ***************** Constructors ********************** //
    public AmbientLight() {
        color = new Color(0, 0, 0);
        Ka = 1;
    }

    public AmbientLight(AmbientLight aLight) {
        this.color = aLight.getColor();
        this.Ka = aLight.getKa();
    }

    public AmbientLight(int r, int g, int b) {
        this.color = new Color(r, g, b);
        this.Ka = 1;
    }

    public AmbientLight(Color color1, double ka1) {
        this.color = color1;
        this.Ka = ka1;
    }

    // ***************** Getters/Setters ********************** //
    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public double getKa() {
        return Ka;
    }

    public Color getIntensity() {
        return new Color((int) (color.getColor().getRed()*Ka),
                (int) (color.getColor().getGreen() * Ka),
                (int) (color.getColor().getBlue() * Ka));

    }
}
