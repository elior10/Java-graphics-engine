package Elements;
import primitives.*;

public class Camera {
    private Point3D p0;
    private Vector vUp;
    private Vector vTo;
    private Vector vRight;

    // ***************** Getters ********************** //
    public Point3D getp0() { return p0; }

    public Vector getvUp() { return vUp;}

    public Vector getvTo() { return vTo; }

    public Vector getvRight() { return vRight; }
    // ***************** Constructors ********************** //
    public Camera()
    {
        this.p0 = new Point3D(0,0,0);
        this.vUp = new Vector(new Point3D(0,1,0));
        this.vTo = new Vector(new Point3D(0,0,-1));
        this.vRight = new Vector(new Point3D(1,0,0));
    };

    public Camera(Point3D p0, Vector vUp, Vector vTo) throws Exception {
        this.p0 = new Point3D(p0);
        this.vUp = new Vector(vUp);
        this.vTo = new Vector(vTo);
        this.vTo = this.vTo.normalize();
        this.vUp = this.vUp.normalize();
        this.vRight = new Vector(vUp.crossProduct(vTo));
        vRight = vRight.normalize();
    }

    public Camera(Point3D p0, Vector vUp, Vector vTo, Vector vRight) throws Exception {
        this.p0 = new Point3D(p0);
        this.vUp = new Vector(vUp);
        this.vTo = new Vector(vTo);
        this.vRight = new Vector(vRight);
        this.vTo = this.vTo.normalize();
        this.vUp = this.vUp.normalize();
        this.vRight = this.vRight.normalize();
    }

    public Camera(Camera camera)
    {
        this.p0 = new Point3D(camera.getp0());
        this.vUp = new Vector(camera.getvUp());
        this.vTo = new Vector(camera.getvTo());
        this.vRight = new Vector(camera.getvRight());
    };
    //************ Function *******************//


    public Ray constructRayThroughPixel(float Nx, float Ny, double i, double j, double screenDist, double screenWidth,double screenHeight) throws Exception {
        Vector vRight1 = new Vector(getvRight());
        Vector vUp1 = new Vector(getvUp());
        Vector tempVTo1 = new Vector(getvTo());
        tempVTo1 = tempVTo1.normalize();
        vRight1 = vRight1.normalize();
        vUp1 = vUp1.normalize();

        Point3D Pc = getp0().PointAddVec(tempVTo1.scale(screenDist));

        // Define the Ratio
        double Rx = screenWidth/Nx;
        double Ry = screenHeight/Ny;

        double NxRx = (i-Nx/2)*Rx+(Rx/2);
        double NyRy = (j-Ny/2)*Ry+(Ry/2);

        // Rays for ray construct
        Point3D p = Pc.PointAddVec(vRight1.scale(NxRx).subtract(vUp1.scale(NyRy)));
        Vector vecTest = (vRight1.scale(NxRx).subtract(vUp1.scale(NyRy)));
        //System.out.println(p);

        Vector vec =  p.subPoint(getp0()).normalize();

        return new Ray(p,vec);

    };


}
