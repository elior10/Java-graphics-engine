package Elements;

import primitives.Point3D;
import primitives.Vector;
import primitives.Color;
import java.awt.*;

public interface LightSource {
    Color getIntensity(Point3D point3D) throws Exception;
    Vector getL(Point3D point3D) throws Exception;
}
