// קרדיט ליוחנן חייק ולעידו הראל

package Elements;

import primitives.Point3D;
import primitives.Vector;
import primitives.Color;
import java.awt.*;

public class SpotLight extends PointLight {

    private Vector _direction;
    // ***************** Constructor ********************** //
    public SpotLight(Color color, Point3D position, Vector direction,
                     double kc, double kl, double kq) throws Exception {
        super(color, position, kc, kl, kq);
        _direction = direction;
        _direction = _direction.normalize();

    }

    // ***************** Getters/Setters ********************** //
    public Color getIntensity(Point3D point) throws Exception {
        Color pointLightColor = super.getIntensity(point);
        Vector l = super.getL(point);
        l = l.normalize();
        double k = Math.abs(_direction.dotProduct(l));
        if(k > 1) {k = 1;}
        java.awt.Color myColor = pointLightColor.getColor();
        return new Color(
                (int)(myColor.getRed()*k)%256,
                (int)(myColor.getGreen()*k)%256,
                (int)(myColor.getBlue()*k)%256);
    }
}