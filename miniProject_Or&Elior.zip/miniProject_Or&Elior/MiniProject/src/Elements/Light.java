package Elements;

import java.awt.*;
import primitives.Color;

public abstract class Light {

    protected Color color;
    abstract public Color getIntensity();

}
