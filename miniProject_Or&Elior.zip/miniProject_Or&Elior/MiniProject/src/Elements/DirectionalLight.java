// קרדיט ליוחנן חייק ולעידו הראל

package Elements;

import primitives.Point3D;
import primitives.Vector;
import primitives.Color;
import java.awt.*;

public class DirectionalLight extends Light implements LightSource {

    private Vector direction;

    // ***************** Constructors ********************** //
    public DirectionalLight(Color color1, Vector direction1) throws Exception {
        color = color1;
        direction = direction1;
        direction = direction.normalize();

    }

    // ***************** Getters/Setters ********************** //
    public Color getIntensity() {
        return color;
    }

    public Color getIntensity(Point3D point){
        return getIntensity();
    }

    public Vector getDirection(){ return direction; }

    public void setDirection(Vector direction1){ this.direction = direction1;}

    public Vector getL(Point3D point) throws Exception {
        direction = direction.normalize();
        return direction;
    }
}